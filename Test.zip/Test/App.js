/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow
 */

import React from 'react';
import { View, StatusBar, YellowBox, PermissionsAndroid,Text, TouchableOpacity, ScrollView } from 'react-native';
import Geolocation from '@react-native-community/geolocation';
import BackgroundTimer from 'react-native-background-timer';

export default class App extends React.Component {
  constructor(props) {
    super(props);
    this.state =  {
       interval_id:0,
       latitude: "",
       longitude: "",
       arrayOflatitude:[]
    }
   
  }

  async componentDidMount() {
     await requestLocationPermission();
  }

  onPressTitle =()=>{
   let interval_id = BackgroundTimer.setInterval(async () => {
     Geolocation.getCurrentPosition(
      position => {
       console.log(position.coords.latitude)
        this.setState({latitude: position.coords.latitude,longitude: position.coords.longitude});
       //this.setState({...arrayOflatitude,arrayOflatitude:{latitude: position.coords.latitude,longitude: position.coords.longitude}})
        this.state.arrayOflatitude.push({latitude: position.coords.latitude,longitude: position.coords.longitude})
        //this.arrayOflatitude.push({latitude: position.coords.latitude,longitude: position.coords.longitude})
      },
      error => this.setState({ error: error.message }),
      { enableHighAccuracy: false, timeout: 200000, maximumAge: 1000 }
   )
    
  }, 10000);
   this.setState({interval_id:interval_id})

 }

stopBackgroundThead =() =>{
   BackgroundTimer.clearInterval(this.state.interval_id);
}

clearBackground=() =>{
  this.setState({arrayOflatitude:[]})
   BackgroundTimer.clearInterval(this.state.interval_id);
}

  render() {
     return (
      <ScrollView>

        <View style={{ flex: 1 }}>
        <View  style ={{flexDirection :"row", marginTop:50,  justifyContent: "space-around"}}>
        <View style ={{ backgroundColor:"blue" }}  >
        <TouchableOpacity onPress={()=>this.onPressTitle()}>
        <Text>
         GET LOCATION
        </Text>
        </TouchableOpacity>
        </View>
         <View style ={{ backgroundColor:"red"}}  >
         <TouchableOpacity onPress={()=>this.clearBackground()}>
         <Text >
          CLEAR
        </Text>
        </TouchableOpacity>
        </View>              
        <View style ={{backgroundColor:"green"}}  >
         <TouchableOpacity onPress={()=>this.stopBackgroundThead()}>
        <Text>
          STOP
        </Text>
        </TouchableOpacity>
        </View>   
        </View> 
        <View style ={{ margin:50}}  >
        {this.state.arrayOflatitude.map((r, index) =>
        <Text key ={index.toString()}>
        {r.latitude} {r.longitude} 
        </Text>
        )}
        </View>
       </View>
       </ScrollView>

      )
    
   }
}

export async function requestLocationPermission() {
  try {
    const granted = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
      {
        'title': 'Access Location',
        'message': 'Delivery App access to your location'
      }
    )
    if (granted === PermissionsAndroid.RESULTS.GRANTED) {
      console.log("You can use the location")
    } else {
      console.log("location permission denied")
    }
  } catch (err) {
     console.warn(err)
  }
}
