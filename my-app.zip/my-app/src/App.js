import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import { Container, Row, Col } from 'reactstrap';
import { borderRadius, height, width } from '@material-ui/system';
import TextField from '@material-ui/core/TextField';
import { green } from '@material-ui/core/colors';
import RadioButtonUncheckedIcon from '@material-ui/icons/RadioButtonUnchecked';
import RadioButtonCheckedIcon from '@material-ui/icons/RadioButtonChecked';
import { withStyles } from '@material-ui/core/styles';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormControl from '@material-ui/core/FormControl';
import FormLabel from '@material-ui/core/FormLabel';
import Fab from '@material-ui/core/Fab';
import { Divider } from '@material-ui/core';
import clsx from 'clsx';
const useStyles = makeStyles(theme => ({
  root: {
    flexGrow: 1,
    backgroundColor: "#F5F5F5"
  },
  root1: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  menuButton: {
    marginRight: theme.spacing(2),
  },
  margin: {
    margin: theme.spacing(1),
    marginTop: 10
  },
  title: {
    flexGrow: 1,
  },
  marginValues: {
    flexGrow: 1,
    margin: 10
  },
  card: {
    flexGrow: 1,
    width: 500,
    marginLeft: 60,
    marginTop: 50,
    backgroundColor: "#FFFFF",
    borderRadius: 5

  },
  paymentCard: {
    flexGrow: 1,
    width: 500,
    marginLeft: 60,
    marginTop: 10,
    backgroundColor: "#FFFFF",
    borderRadius: 5
  },
  order: {
    flexGrow: 1,
    marginTop: 10,
    maxWidth: "50%",
    height: 380,
    marginLeft: -12,
    backgroundColor: "#FFFFF",
    borderRadius: 5

  },
  dense: {
    marginTop: theme.spacing(2),
  },
  address: {
    marginTop: 50,
    maxWidth: "50%",
    height: 50,
    marginLeft: -12,
    backgroundColor: "#FFFFF",
    borderRadius: 5

  },
  cardAlign: {
    flexDirection: "row",
    flexGrow: 1,
    marginLeft: 10
  },
  container: {
    flexGrow: 1,
    display: 'flex',
    flexDirection: "row",
    flexWrap: 'wrap',
    marginLeft: 4
  },
  container1: {   
    marginLeft:0,
    flexDirection: "row",
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    
   
  },

  container13:{
  borderTopLeftRadius: 10,
  borderTopRightRadius: 10,
  marginLeft:-80

  },

  container12:{
    marginLeft:5,
    borderBottomLeftRadius: 10,
    borderBottomRightRadius: 10,
      },
  timeCard: {
    flexWrap: 'wrap',
    width: 35,
    height: 35,
    borderBlock: 1,
    borderColor: "#000000",
    backgroundColor: "#FFFFFF",
    borderRadius: 5,
    marginLeft: 10

  },

  timeCard1: {
    flexWrap: 'wrap',
    width: 80,
    height: 25,
    borderWidth: 1.5,
    borderColor: "#0000000",
    backgroundColor: "#FFFFFF",
    borderRadius: 5,
    margin: 10

  },

  bullet: {
    display: 'inline-block',
    margin: '0 2px',
    transform: 'scale(0.8)',
  },
  title: {
    margin: 5,
    fontSize: 10,
  },
  titleColor:{
    margin: 5,
    fontSize: 10,
   color:"#B8D35C"
  },
  title1: {
    fontSize: 14,
    marginTop: 50
  },
  titleValues: {
    marginLeft: 10,
    justifyContent: "center",
    fontSize: 10,
    marginTop: 10

  },

    textField: {
      marginLeft: theme.spacing(2),
      marginRight: theme.spacing(2),
    },
   
    textField22:{
      marginLeft: theme.spacing(-0),
      marginRight: -10,
    },
  

  spacing: {   
    width:50,
    marginLeft: theme.spacing(1),
    marginRight: theme.spacing(1),
    borderRadius:5,
    alignItems: 'center',
    
  },
  spacingRight: {
    width:50,   
    marginLeft: theme.spacing(1),
    marginRight: theme.spacing(1),
    alignItems: 'center',
    
  },
  pos: {
    marginBottom: 12,
  },
  bColor: {
    backgroundColor: "#F5F5F5",
    marginBottom: 10,
    height: 500
  },
  mColor: {
    backgroundColor: "green"
  },
  yColor: {
    backgroundColor: "yellow"
  },
  formControl: {
    margin: theme.spacing(3),
  },
  group: {
    margin: theme.spacing(1),
  },
  paper: {
    padding: theme.spacing(4),
    marginTop:10,    
   
    color: theme.palette.text.secondary,
  },
  paperTop: {
    padding: theme.spacing(2),
    marginTop:1,    
    color: theme.palette.text.secondary,
  },
 
  textView: {
   
    marginLeft:10,    
    color: theme.palette.text.secondary,
  },
  paper1:{
    padding: theme.spacing(1),
    marginTop:10,   
    textAlign: 'center',
    color: theme.palette.text.secondary,
  },
  fab: {
    margin: theme.spacing(1),
    marginTop:20,
    marginLeft:10,
    width:250, 
    color:"#FFFFFF",
    backgroundColor:"#00BCCD"
  },
  lableColor:{
   color:"#FFFFFFF"
  },
  extendedIcon: {
    marginRight: theme.spacing(1),
  },
}));

const useStyless = makeStyles(theme => ({
  root1: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'space-between',
    backgroundColor: "#F5F5F5"

  },

}));


export default function App() {
  const [value, setValue] = React.useState('female');

  function handleChange(event) {
    setValue(event.target.value);
  }


  const classes = useStyles();
  const classess = useStyless();
  const bull = <span className={classes.bullet}>•</span>;
  var tmp = [];
  for (var i = 0; i < 4; i++) {
    tmp.push(i);
  }
  var tmp1 = [];
  for (var i = 0; i < 5; i++) {
    tmp1.push(i);
  }

  var indentsa = tmp1.map(function (i) {
    return (
      <Grid item xs={2.5} >
        <Paper className={classes.timeCard1}>
          <Typography variant="h1" className={classes.titleValues}>
            07 AM -10 AM
       </Typography>
        </Paper>
      </Grid>
    );

  });

  


  var indents = tmp.map(function (i) {
    return (
      <Grid item xs={1.5} >
        <Paper className={classes.timeCard}>
          <Typography variant="h1" className={classes.title}>
            FRI
       </Typography>
          <Typography variant="h1" className={classes.title}>
            23
    </Typography>

        </Paper>
      </Grid>
    );
 });

  return (
    <div className={classes.root}>
      <AppBar position="static">
        <Toolbar>
          <IconButton edge="start" className={classes.menuButton} color="inherit" aria-label="menu">
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" className={classes.title}>
            News
          </Typography>
          <Button color="inherit">Login</Button>
        </Toolbar>
      </AppBar>  
      
      <Grid container  container
        spacing={0}
        alignItems="center"
        borderRadius = "5"
        justify="center" style={{ minHeight: '80vh' }} >
       <Grid item xs={5} className={classes.spacing}  >
    
      





          <Paper className={classes.paperTop}>
        
          <Grid container spacing={3}>
        
        <Grid item xs={12} sm={9}>
        <Typography className={classes.title} color="textSecondary" gutterBottom>
          SELECT YOUR DELIVERY SLOT     
            </Typography>
        </Grid>
        <Grid item xs={12} sm={3}>
        <Paper className={classes.timeCard1}>
          <Typography variant="h1" className={classes.titleValues}>
            07 AM -10 AM
         </Typography>
        </Paper>
        </Grid>
     
      </Grid>
        
               
            <Row className={classes.container}>
              {indents}
            </Row>
            <Typography className={classes.title1} color="textSecondary" gutterBottom>
              AVAILABLE TIME SLOT
                   </Typography>
            <Row className={classes.container}>
              {indentsa}
            </Row>
          </Paper>
          <Paper className={classes.paper}>
            <Typography className={classes.title} color="textSecondary" gutterBottom>
              SELECT YOUR PAYMENT METHOD
                 </Typography>
            {/* <RadioGroup 
              aria-label="gender"
              name="gender1"
              className={classes.title}
              value={value}
              onChange={handleChange}
              size ={"small"}
            > */}
              <Typography variant="h1" className={classes.titleValues}>
              Cash on Delivery
              </Typography>  
              <Typography variant="h1" className={classes.titleValues}>
                Credit/Debit Card
               </Typography>  
               <Typography variant="h1" className={classes.titleValues}>
            PROMOCODE
     
              </Typography> 



      <Grid container spacing={0}>
       
        <Grid item xs={6} spacing={0}>
        <TextField
        id="outlined-dense"
        className={clsx(classes.textField22, classes.dense)}
        margin="dense"
        variant="outlined"
        />
        </Grid>
        <Grid item xs={6}>
        <Button variant="contained" color="primary"  className={clsx(classes.textField22, classes.dense)}>
        Primary
        </Button>
        </Grid>
       
      </Grid>





    
          </Paper>
        </Grid>
        <Grid item xs={3}  className={classes.spacingRight}>
          <Paper className={classes.paper1}>
            <Typography className={classes.titleColor} color="textSecondary" gutterBottom>
             + ADD DELIVERY ADDRESS
                 </Typography>
          </Paper>
          <Paper className={classes.paper}>          
                <Typography className={classes.title} color="textSecondary" gutterBottom>
                  YOUR ORDER
                   </Typography>
                   <Typography className={classes.title} color="textSecondary" gutterBottom>
                    Chicken Breast Boneless
                   </Typography>                    
                    <Row className={classes.container}>                    
                      <Col>
                      <Paper className={classes.timeCard1}>
                      <Typography variant="h1" className={classes.titleValues}>
                       450grms
                      </Typography>
                      </Paper>
                      </Col>
                      <Col>
                      <Typography variant="h1" className={classes.titleValues}>
                       450grms
                      </Typography>
                      </Col>
                    </Row>                  
                    <Divider light />

                    <Typography className={classes.title} color="textSecondary" gutterBottom>
                     King Fish Fillet(Medium)
                   </Typography> 
                    <Row className={classes.container}>                    
                      <Col>
                      <Paper className={classes.timeCard1}>
                      <Typography variant="h1" className={classes.titleValues}>
                       450grms
                      </Typography>
                      </Paper>
                      </Col>
                      <Col>
                      <Typography variant="h1" className={classes.titleValues}>
                       450grms
                      </Typography>
                      </Col>
                    </Row>  
                    <Divider variant="middle"  />
                    <Row className={classes.container}>                    
                      <Col>
                     
                      <Typography variant="h1" className={classes.titleValues}>
                       Subtotal
                      </Typography>
                     
                      </Col>
                      <Col>
                      <Typography variant="h1" className={classes.titleValues}>
                       450grms
                      </Typography>
                      </Col>
                    </Row>  
                    <Row className={classes.container}>                    
                      <Col>                     
                      <Typography variant="h1" className={classes.titleValues}>
                       Delivery Charges
                      </Typography>                     
                      </Col>
                      <Col>
                      <Typography variant="h1" className={classes.titleValues}>
                       450grms
                      </Typography>
                      </Col>
                    </Row>  
                    <Row className={classes.container}>                    
                      <Col>                    
                      <Typography variant="h1" className={classes.titleValues}>
                       Taxes
                      </Typography>                      
                      </Col>
                      <Col>
                      <Typography variant="h1" className={classes.titleValues}>
                       450grms
                      </Typography>
                      </Col>
                    </Row>  
                    <Typography variant="h1" className={classes.titleValues}>
                    </Typography>
                    <Divider light />
                    <Row className={classes.container}>                    
                      <Col>                    
                      <Typography variant="h1" className={classes.titleValues}>
                       Total
                      </Typography>                      
                      </Col>
                      <Col>
                      <Typography variant="h1" className={classes.titleValues}>
                       450grms
                      </Typography>
                      </Col>
                    </Row>  

                    <Button variant="contained" color="primary" className={classes.fab}>
                    PLACE ORDER
                    </Button>
                   
              </Paper>
        </Grid>

      </Grid>
    </div>
  );
}






